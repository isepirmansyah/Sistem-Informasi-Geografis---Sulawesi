<h4
    <?php echo e($attributes->class(['fi-ta-empty-state-heading text-base font-semibold leading-6 text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h4>
<?php /**PATH D:\KULIAH NF\KULIAH\Semester 7\Sistem Informasi Geografis\App Project\Project-Uas-SIG\vendor\filament\tables\src\/../resources/views/components/empty-state/heading.blade.php ENDPATH**/ ?>